#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bitmap.h"
#include "utilities.h"
#include "c_mode.h"


#define BUFFER_SIZE 256
//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

typedef struct Board_data board_data;
typedef struct Component_track *head;
typedef struct Bmp bmp;


Bmp cleaned_image(Bmp *bmp, Component_track *head, int start, int end){
    Component_track *current = head;

    /*creating a copy of bmp to get threshold, this is done to stop any
    undefined behaviour in the case where we just keep editing the same Bmp file*/
    Bmp new_bmp = copy_bmp(*bmp); 

    gray_img(new_bmp);

    while(current != NULL) {
        //We don't want to delete the template data of the 'start' and 'end' templates
        if (start == current -> id || end == current -> id){
            current = current -> next;
            continue;
        }
        for(int x= 0; x < TEMPLATE_HEIGHT; x++){
            for(int y=0; y < TEMPLATE_WIDTH; y++){
                /*Go to where the components are using a pointer and equate all the RGB to 0 to get a 0 image
                verified using write_bmp*/
                new_bmp.pixels[x + current -> row][y + current -> column][RED] = 0;
                new_bmp.pixels[x + current -> row][y + current -> column][GREEN] = 0;
                new_bmp.pixels[x + current -> row][y + current -> column][BLUE] = 0;
            }
        }
        current = current -> next;
    }

    return new_bmp;
}

int dfs(Component_track *head, Bmp *new_bmp, int row, int col, int end_row, int end_col, int visited[new_bmp->height][new_bmp->width]){
    // Define possible neighbor positions (up, down, left, right)
    int dr[4] = {-1,1,0,0}; 
    int dc[4] = {0,0,-1,1};
    
    //If row and column are not in the bounds of the image and not visited then we exit with no connections
    if(row >= 0 && row < new_bmp->height && col >= 0 && col < new_bmp->width && visited[row][col]){
        return 0;
    }
    //If the row and column of our depth-first search equals to our 'end-goal', we return 1 indicating a connection was found
    if(row == end_row && col == end_col){
        return 1;
    }
    //If the row and column has an value of 0, then we exit indicating no connection
    if(!avg_colour(row, col,*new_bmp)){
        return 0;
    }

    //After going through all those if statements, indicate that we have visited this region
    visited[row][col] = 1;

    //Go through 4 neighboring regions and recursively use depth-first search to find a connection or exit
    for (int i = 0; i < 4; i++) {
        
        int newRow = row + dr[i];
        int newCol = col + dc[i];

        // Explore neighboring cells
        // Check if the neighboring cell is within bounds and unvisited
        if (dfs(head, new_bmp, newRow, newCol, end_row, end_col, visited)){
            return 1;
        }
    }   

    // No connection found after checking all neighbors
    return 0;
}

void print_c_mode(int list_size, int comp_found[list_size][list_size]){
    //Iterate through connections
    for(int i = 0; i < list_size; i++){
        printf("Component %d connected to ", i);
        int connected = 0;
        for(int j = 0; j < list_size; j++){
            if(comp_found[i][j]){
                printf("%d ", j);
                connected = 1;
            } 
        }
        if(!connected){
            printf("nothing");
        }
        // New line for next component
        printf("\n"); 
    }
}

void c_mode(Board_data board_data, Component_track *head) {
    Bmp bmp = read_bmp(board_data.image_file);
    int list_size = sizeoflinklist(head);
    int comp_found[list_size][list_size]; //store components connected to each other or connections found 
    memset(comp_found, 0, sizeof(comp_found)); //memset used to remove any garbage values and set all to no connections 

    Component_track *start = head;

    for (int start_i = 0; start != NULL; start_i++) {
        //must return to head for every time we use start_i
        Component_track *end = start->next;

        for(int end_i = start_i + 1; end != NULL; end_i++){

            //Refer to description of function above
            Bmp cleaned_bmp = cleaned_image(&bmp, head, start_i, end_i);

            //Set all of visited to 0 and make it 1 for each iteration of dfs
            int visited[bmp.height][bmp.width];
            memset(visited, 0, sizeof(visited));

            // Perform DFS starting from this unvisited component
            // If there is a connection, we store this in our comp_found
            if(dfs(head, &cleaned_bmp, start->row, start->column, end->row, end->column, visited)){
                //A connection between start_i and end_i is the same as a connection between end_i and start_i
                comp_found[start_i][end_i] = 1;
                comp_found[end_i][start_i] = 1;        
            }

            free_bmp(cleaned_bmp);  // Free memory for cleaned_bmp
            
            //next iteration of the linked list
            end = end->next;
        }
        start = start->next;
    }
    print_c_mode(list_size, comp_found);

    free_bmp(bmp);
}

