#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 256
//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

#include "bitmap.h"
#include "utilities.h"
#include "t_mode.h"
#include "l_mode.h"
#include "c_mode.h"

int process_board(Board_data board_data) {
    //Open the template file
    FILE *fp_temp;
    fp_temp = open_temp_file(&board_data, fp_temp);
    //Get the total amount of component templates from the template file and store
    int total_index = fgetc(fp_temp);

    //Initialise a 3D array of known size and store all the templates in it
    int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH];
    load_templates(fp_temp, total_index, template_data);

    if (board_data.mode == 't'){
        //extract inputed index in board_data
        int index = atoi(board_data.image_file);
        //index must be smaller than total_index as index ranges between 0 and total_index - 1
        if (index < total_index){
            t_mode(total_index, template_data, index); 
        }
        else{
            printf("Template index out of range\n");
        }
    }
    else{
        //Find all components and return linked list for later use for c_mode
        Component_track *head = l_mode(board_data, fp_temp, total_index, template_data);
        if (board_data.mode == 'c'){
            c_mode(board_data, head);
        }

        //free linked list
        while(head != NULL){
            Component_track *component = head;
            head = head -> next;
            free(component);
        }
    }

    fclose(fp_temp); //Remember to close template file! This could be closed after we store in template_data aswell

    return 0;  // Return 0 to indicate success
}


int main(int argc, char *argv[]) {
    Board_data board_data;

    //Arguement length input must be correct
    if (argc != 4) {
        printf("Invalid arguements!\n");
        return 1;  // Return 1 to indicate an error
    }

    //Store arguements inputed from stdin
    /*Storing the mode, note that argv is a double pointer to an array of characters and we just need to 
    store a character (t,l,c) for the mode, so we must take the first character of argv[1]*/
    board_data.mode = argv[1][0]; 

    if ((board_data.mode != 't' && board_data.mode != 'l' && board_data.mode != 'c') && argc == 4) {
        printf("Invalid mode selected!\n");
        return 1; //Return 1 to indicate an error
    }       

    //Storing the template file name
    strcpy(board_data.temp_file, argv[2]);
    board_data.temp_file[BUFFER_SIZE - 1] = '\0';  // Ensure null-terminated string
    //Storing the bmp file name
    strcpy(board_data.image_file, argv[3]);
    board_data.image_file[BUFFER_SIZE - 1] = '\0';  // as above


    int trouble_encountered = process_board(board_data);

    if (trouble_encountered) {
        return 1;  // Exit with a non-zero value to indicate an error
    }

    return 0;  // Return 0 to indicate successful program execution
}



