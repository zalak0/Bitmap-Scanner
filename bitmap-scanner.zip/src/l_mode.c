#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "bitmap.h"
#include "utilities.h"
#include "l_mode.h"

#define BUFFER_SIZE 256
//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

typedef struct Board_data board_data;
typedef struct Component_track *head;
typedef struct Bmp bmp;

int **convert_pix_to_bin(Bmp bmp){
    int **bmp_pix;

    bmp_pix = (int **)malloc(bmp.height * sizeof(int *));
    for (int i = 0; i <= bmp.height; i++) {
        bmp_pix[i] = (int *)malloc(bmp.width * sizeof(int));
    }

    //Go through every pixel, find the avg_colour and print a 0 or 1 as a result
    
    for(int row = 0; row < bmp.height; row++){
        for(int col = 0; col< bmp.width; col++){
            int avg = avg_colour(row, col, bmp);
            if (avg >= 128){
                bmp_pix[row][col] = 1;
            }   
            else{
                bmp_pix[row][col] = 0;
            }
        }
    }

    return bmp_pix;
}

void print_l_mode(Component_track *head, int component_number){
    Component_track *component = head;

    //Printing results 
    printf("Found %d components:\n", component_number);

    //id_counter used later in c_mode
    int id_counter = 0;
    while(component != NULL){
        printf("type: %d, row: %d, column: %d\n", component -> type, component -> row, component -> column);
        component -> id = id_counter;
        id_counter++;
        component = component -> next;
    }
}

Component_track *l_mode(Board_data board_data, FILE *fp_temp, int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH]){
    /* Using bitmap.h, read_bmp reads file and gives us the height, width 
    and a triple pointer to the pixels*/
    Bmp bmp = read_bmp(board_data.image_file);

    /*threshold's the bmp pixels making them either black or white, this can be 
    verified using the write_bmp function*/
    gray_img(bmp); 

    /*convert RGB to binary so we are only dealing with 0's and 1's
    this is used to compare to template_data with is stored in binary*/

    int **bmp_pix = convert_pix_to_bin(bmp);

    int component_number = 0;
    Component_track *head = NULL;

    /*This is to scan over each 32 x 32 of the pcb image to find a template match
    We won't include the last 32 bytes for each template. This will be scanned later*/
    //Think of the next two for loops as pivots on the top right of each template
    //Iterate through each index in template_data
    for (int index = 0; index < total_index; index++){
        for (int row_img = 0; row_img <= bmp.height - TEMPLATE_HEIGHT; row_img++){

            for(int width_img = 0; width_img <= bmp.width - (TEMPLATE_WIDTH); width_img++){
                int temp_match = 1;

                //This nexted for loop will compare each pixel as a result
                //Iterate through each row in template_data
                for(int row_temp = 0; row_temp < TEMPLATE_HEIGHT && temp_match == 1; row_temp++){
                    //Iterate through each bit to compare the bmp pixels to template_data and find a possible match
                    for(int width_temp = 0; width_temp < (TEMPLATE_WIDTH) && temp_match == 1; width_temp++){
                        int bin_pixel = bmp_pix[row_img + row_temp][width_img + width_temp];

                        /*Every pixel of the bmp_pix array or the bmp image must align with every pixel of the template_data
                        to identify as a component, or else there is no match*/
                        if(bin_pixel != template_data[index][TEMPLATE_HEIGHT - row_temp - 1][width_temp]){
                            temp_match = 0;
                        }   
                    }
                }
                /*If there is a temp match, then a component is found on board, 
                and we must create memory and assign values for the new component*/
                if(temp_match){
                    Component_track* component_found = malloc(sizeof(Component_track));
                    component_found -> type = index;
                    component_found -> row = row_img;
                    component_found -> column = width_img;
                    component_found -> next = NULL;

                    insertOrdered(&head, component_found);
                    component_number++;
                }
            }
        }
    }

    //Freeing memory
    free_bmp(bmp);
    //Free bmp_pix
    for (int i =0; i <= bmp.height; i++){
        free(bmp_pix[i]);
    }
    free(bmp_pix);

    //print stored components found
    print_l_mode(head, component_number);

    return head;
}
