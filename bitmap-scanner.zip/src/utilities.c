#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bitmap.h"
#include "utilities.h"

#define BUFFER_SIZE 256
//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

typedef struct Board_data board_data;
typedef struct Component_track *head;
typedef struct Bmp bmp;

// Function to insert the component in order
void insertOrdered(Component_track** head, Component_track* newComp) {
    // If the list is empty or if the new component should be placed before the first component
    if (*head == NULL || (*head)->row > newComp->row || ((*head)->row == newComp->row && (*head)->column > newComp->column)) {
        newComp->next = *head;
        *head = newComp;
    } else {
        // Find the correct insertion point
        Component_track* current = *head;
        while (current->next != NULL && 
        (current->next->row < newComp->row || (current->next->row == newComp->row && current->next->column < newComp->column))) {
            current = current->next;
        }

        // Insert new component after 'current'
        newComp->next = current->next;
        current->next = newComp;
    }
}

int sizeoflinklist(Component_track* head){
    Component_track* temp = head; //assign a temp node to the head of the list
    int count=0;

    while(temp) {
        count++;
        temp = temp->next; //move to next node
    }

    return count;
}

int avg_colour(int row, int col, Bmp bmp) {
    int avg = (bmp.pixels[row][col][RED] + bmp.pixels[row][col][GREEN] + bmp.pixels[row][col][BLUE])/3;
    return avg;
}


void gray_img(Bmp bmp){
    for(unsigned int row = 0; row < bmp.height; row++){
        for(unsigned int col = 0; col < bmp.width; col++){
            int average_colour = avg_colour(row, col, bmp);
            if (average_colour >=  128){
                /*make a file before going forward. Print 1's and zeroes in the file
                based on the average of the RGB values in this for loop. We will
                link up the components later, figure that out somehow*/
                bmp.pixels[row][col][RED] = 255;
                bmp.pixels[row][col][GREEN] = 255;
                bmp.pixels[row][col][BLUE] = 255;
                continue;
            }
            else{
                bmp.pixels[row][col][RED] = 0;
                bmp.pixels[row][col][GREEN] = 0;
                bmp.pixels[row][col][BLUE] = 0;
                continue;
            }
        }
    }
}
