#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utilities.h"
#include "t_mode.h"


#define BUFFER_SIZE 256
//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

typedef struct Board_data board_data;

FILE *open_temp_file(Board_data *board_data, FILE *fp_temp){
    fp_temp = fopen(board_data->temp_file, "rb");

    if (fp_temp == NULL) {
        printf("Can't load template file\n");
        exit(1);  // Exit with a non-zero value to indicate an error
    }
    return fp_temp;
}

void load_templates(FILE *fp_temp, int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH]){
    for (int temp_index = 0; temp_index < total_index; temp_index++){
        /*loop is not recorded in row and width but rather in iteration of bytes as a binary file technically
        has not rows or width. However, we want to keep track of the row and width to add it to our template_data 
        array and allow for easier extraction when printing and later in l_mode*/
        int row_index = 0;
        int width_index = 0;

        int offset = TEMPLATE_BYTES*(temp_index) + 1; //First byte represents index size
        //Go to bottom left of the file
        fseek(fp_temp, offset + TEMPLATE_BYTES - 4, SEEK_SET);

        for(int byte = 128; byte > 0; byte--){
            //Get next byte
            int g = fgetc(fp_temp);

            for (int bit = 7; bit >=0; bit--) {
                //Go through each bit and store a 1 or 0 corresponding to the bit
                if ((g >> bit) & 1) {
                    template_data[temp_index][row_index][width_index] = 1;
                } 
                else {
                    template_data[temp_index][row_index][width_index] = 0;
                }
                width_index++;
            }    

            /*Our templates ar 32 x 32, and every row has 4 bytes (32 bits), so every 4 bytes we read,
            we go to the above line and continue reading*/
            if ((byte - 1) % 4 == 0 && byte != 1) {
                fseek(fp_temp, -8, SEEK_CUR);
                row_index++;
                width_index = 0;
            }
        }
    }
}

void t_mode(int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH], int index) {
    printf("Template data:\n");
    //print a 32 x 32 image using stored template_data array
    for(int i = 0; i < TEMPLATE_HEIGHT; i++){
        for(int j = 0;j < TEMPLATE_WIDTH; j++){
            if (template_data[index][i][j]){
                printf("1");
            } 
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
}
