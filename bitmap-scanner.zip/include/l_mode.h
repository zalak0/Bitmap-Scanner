#ifndef _L_MODE_H
#define _L_MODE_H

//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

//convert triple pointer to pixels in Bmp struct to useable and comparable binary outputs
int **convert_pix_to_bin(Bmp bmp);

//print the components found, type and position
void print_l_mode(Component_track *head, int component_number);

//Finding the components
Component_track *l_mode(Board_data board_data, FILE *fp_temp, int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH]);

#endif
