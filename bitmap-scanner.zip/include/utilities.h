#ifndef _UTILITIES_H
#define _UTILITIES_H

#include "bitmap.h"

#define BUFFER_SIZE 256

//Store Arguements inputed in stdin
typedef struct {
    char mode;
    char temp_file[BUFFER_SIZE];
    char image_file[BUFFER_SIZE];
}Board_data;

//linked list
typedef struct Component_track {
    int type;
    int row;
    int column;
    int id;
    struct Component_track* next;
}Component_track;

//insert new node of linked list in a ordered fashion for easier use
void insertOrdered(Component_track** head, Component_track* newComp);

//find size of linked list
int sizeoflinklist(Component_track* head);

//Find the average colour of the RGB pixels (used mainly for threshold)
int avg_colour(int row, int col, Bmp bmp);

//Used to threshold an image
void gray_img(Bmp bmp);

#endif
