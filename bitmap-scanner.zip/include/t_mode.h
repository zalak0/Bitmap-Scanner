#ifndef _T_MODE_H
#define _T_MODE_H

//Size of each index
#define TEMPLATE_BYTES 128
#define TEMPLATE_HEIGHT 32
#define TEMPLATE_WIDTH 32

//open template file
FILE *open_temp_file(Board_data *board_data, FILE *fp_temp);

//store all the templates in 3d array called template_data
void load_templates(FILE *fp_temp, int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH]);

//Print the desired component based on input 
void t_mode(int total_index, int template_data[total_index][TEMPLATE_HEIGHT][TEMPLATE_WIDTH], int index);

#endif
