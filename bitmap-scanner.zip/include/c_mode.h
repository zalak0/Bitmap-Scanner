#ifndef _C_MODE_H
#define _C_MODE_H

/*We want image to delete all but 2 components and find the connection between them in each iteration
of c_mode, which is done using this function*/
Bmp cleaned_image(Bmp *bmp, Component_track *head, int start, int end);

//Component connections are found using depth-first search algorithm (below function)
int dfs(Component_track *head, Bmp *new_bmp, int row, int col, int end_row, int end_col, int visited[new_bmp->height][new_bmp->width]);

//Print component connections found (if any)
void print_c_mode(int list_size, int comp_found[list_size][list_size]);

/*find connections between components by looping through each component in the list and seeing if there
is a connection between them or not*/
void c_mode(Board_data board_data, Component_track *head);

#endif
